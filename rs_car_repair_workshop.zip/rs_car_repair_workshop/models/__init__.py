# -*- coding: utf-8 -*-

from . import car_repair
from . import checklists
from . import car_diagnosis
from . import work_order
from . import inherited_model